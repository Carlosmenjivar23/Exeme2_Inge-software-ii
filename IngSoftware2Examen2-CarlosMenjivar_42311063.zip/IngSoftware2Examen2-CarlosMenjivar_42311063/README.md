# Refactor for Movement Factory

Original project refactored to use MovementFactory.


## Refactor: MovementFactory and FeeMovement

- Added `src/domain/MovementFactory.js` — central factory for creating IMovement instances.
- Added `FeeMovement` class to `src/domain/Movement.js` to demonstrate OCP (new type without changing UI).
- Updated `src/components/MovementList.*` to use `MovementFactory.create(data)` instead of `new` or `switch` on types.

### How to add a new movement type (OCP)
1. Create a new class in `src/domain/Movement.js` exporting the class, e.g. `export class ChargebackMovement extends Movement { ... }`.
2. Register it in `MovementFactory` by adding `registry['CHARGEBACK'] = ChargebackMovement;`
   - Alternatively, export it as `ChargebackMovement` and MovementFactory will auto-register if implemented.
3. No UI changes required.

