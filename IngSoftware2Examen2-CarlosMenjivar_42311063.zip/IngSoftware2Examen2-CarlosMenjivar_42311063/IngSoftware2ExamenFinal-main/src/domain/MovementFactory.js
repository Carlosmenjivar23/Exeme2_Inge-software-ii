// MovementFactory.js
// Centralized factory for IMovement instances.

import * as MovementModule from './Movement';

const registry = {
  INCOME: MovementModule.IncomeMovement,
  EXPENSE: MovementModule.ExpenseMovement,
  TRANSFER: MovementModule.TransferMovement,
  REFUND: MovementModule.RefundMovement,
  // FEE will be registered below if available
};

export const MovementFactory = {
  create(data) {
    const type = data && data.type;
    const MovementClass = registry[type];
    if (!MovementClass) {
      throw new Error(`MovementFactory: movement type not registered: ${type}`);
    }
    return new MovementClass(data);
  },

  register(type, clazz) {
    registry[type] = clazz;
  },

  _registryForTests() {
    return registry;
  }
};

// If the module exports FeeMovement, register it automatically.
if (MovementModule.FeeMovement) {
  MovementFactory.register('FEE', MovementModule.FeeMovement);
}
